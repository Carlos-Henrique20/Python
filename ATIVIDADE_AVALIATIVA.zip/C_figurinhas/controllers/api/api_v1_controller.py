from flask import Blueprint, jsonify, request

from services import ColecionadorService, FigurinhaService, OfertaService

api_v1_bp = Blueprint("api_v1", __name__, url_prefix="/api/v1")


@api_v1_bp.route("/colecionadores", methods=["GET"])
def listar_colecionadores():
    return jsonify(ColecionadorService.listar()), 200


@api_v1_bp.route("/colecionadores/<int:colecionador_id>", methods=["GET"])
def buscar_colecionador(colecionador_id):
    colecionador = ColecionadorService.buscar_por_id(colecionador_id)
    if not colecionador:
        return jsonify({"erro": "Colecionador não encontrado"}), 404
    return jsonify(colecionador), 200


@api_v1_bp.route("/colecionadores", methods=["POST"])
def criar_colecionador():
    dados = request.get_json(silent=True) or {}
    apelido = dados.get("apelido")
    cidade = dados.get("cidade")

    if not apelido or not cidade:
        return jsonify({"erro": "apelido e cidade são obrigatórios"}), 400

    colecionador = ColecionadorService.criar(apelido, cidade)
    return jsonify(colecionador), 201


@api_v1_bp.route("/figurinhas", methods=["GET"])
def listar_figurinhas():
    return jsonify(FigurinhaService.listar()), 200


@api_v1_bp.route("/figurinhas/<int:figurinha_id>", methods=["GET"])
def buscar_figurinha(figurinha_id):
    figurinha = FigurinhaService.buscar_por_id(figurinha_id)
    if not figurinha:
        return jsonify({"erro": "Figurinha não encontrada"}), 404
    return jsonify(figurinha), 200


@api_v1_bp.route("/figurinhas", methods=["POST"])
def criar_figurinha():
    dados = request.get_json(silent=True) or {}
    try:
        numero = int(dados.get("numero", 0))
    except (TypeError, ValueError):
        return jsonify({"erro": "numero inválido"}), 400

    nome_jogador = dados.get("nome_jogador")
    time = dados.get("time")

    if not numero or not nome_jogador or not time:
        return jsonify({"erro": "numero, nome_jogador e time são obrigatórios"}), 400

    figurinha = FigurinhaService.criar(numero, nome_jogador, time)
    return jsonify(figurinha), 201


@api_v1_bp.route("/ofertas", methods=["GET"])
def listar_ofertas():
    return jsonify(OfertaService.listar()), 200


@api_v1_bp.route("/ofertas/<int:oferta_id>", methods=["GET"])
def buscar_oferta(oferta_id):
    oferta = OfertaService.buscar_por_id(oferta_id)
    if not oferta:
        return jsonify({"erro": "Oferta não encontrada"}), 404
    return jsonify(oferta), 200


@api_v1_bp.route("/ofertas", methods=["POST"])
def criar_oferta():
    dados = request.get_json(silent=True) or {}
    try:
        colecionador_id = int(dados.get("colecionador_id", 0))
        figurinha_oferece_id = int(dados.get("figurinha_oferece_id", 0))
        figurinha_deseja_id = int(dados.get("figurinha_deseja_id", 0))
    except (TypeError, ValueError):
        return jsonify({"erro": "Valores inválidos"}), 400

    observacao = dados.get("observacao", "")

    if not colecionador_id or not figurinha_oferece_id or not figurinha_deseja_id:
        return jsonify(
            {"erro": "colecionador_id, figurinha_oferece_id e figurinha_deseja_id são obrigatórios"}
        ), 400

    if figurinha_oferece_id == figurinha_deseja_id:
        return jsonify({"erro": "A figurinha oferecida e a desejada não podem ser iguais"}), 400

    oferta = OfertaService.criar(colecionador_id, figurinha_oferece_id, figurinha_deseja_id, observacao)
    if not oferta:
        return jsonify({"erro": "Colecionador ou figurinha inválidos"}), 400

    return jsonify(oferta), 201


@api_v1_bp.route("/status", methods=["GET"])
def status():
    return jsonify({"status": "API está funcionando"}), 200
