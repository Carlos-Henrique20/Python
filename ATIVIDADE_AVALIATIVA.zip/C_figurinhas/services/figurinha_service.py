from models import Figurinha, db


class FigurinhaService:
    @staticmethod
    def listar():
        return [FigurinhaService.to_dict(figurinha) for figurinha in Figurinha.listar()]

    @staticmethod
    def buscar_por_id(figurinha_id):
        figurinha = db.session.get(Figurinha, figurinha_id)
        return FigurinhaService.to_dict(figurinha) if figurinha else None

    @staticmethod
    def criar(numero, nome_jogador, time):
        figurinha = Figurinha(numero=numero, nome_jogador=nome_jogador, time=time)
        db.session.add(figurinha)
        db.session.commit()
        return FigurinhaService.to_dict(figurinha)

    @staticmethod
    def to_dict(figurinha):
        return {
            "id": figurinha.id,
            "numero": figurinha.numero,
            "nome_jogador": figurinha.nome_jogador,
            "time": figurinha.time,
        }
