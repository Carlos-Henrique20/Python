from models import Colecionador, Figurinha, OfertaTroca, db


class OfertaService:
    @staticmethod
    def listar():
        return [OfertaService.to_dict(oferta) for oferta in OfertaTroca.listar_com_colecionador()]

    @staticmethod
    def buscar_por_id(oferta_id):
        oferta = db.session.get(OfertaTroca, oferta_id)
        return OfertaService.to_dict(oferta) if oferta else None

    @staticmethod
    def criar(colecionador_id, figurinha_oferece_id, figurinha_deseja_id, observacao=""):
        if not db.session.get(Colecionador, colecionador_id):
            return None
        if not db.session.get(Figurinha, figurinha_oferece_id) or not db.session.get(Figurinha, figurinha_deseja_id):
            return None

        oferta = OfertaTroca.criar_com_itens(
            colecionador_id, figurinha_oferece_id, figurinha_deseja_id, observacao
        )
        return OfertaService.to_dict(oferta)

    @staticmethod
    def to_dict(oferta):
        return {
            "id": oferta.id,
            "colecionador_id": oferta.colecionador_id,
            "colecionador": oferta.colecionador.apelido,
            "observacao": oferta.observacao,
            "itens": [
                {
                    "tipo": item.tipo,
                    "figurinha_id": item.figurinha_id,
                    "figurinha": item.figurinha.nome_jogador,
                    "quantidade": item.quantidade,
                }
                for item in oferta.itens
            ],
        }
