from models import Colecionador, db


class ColecionadorService:
    @staticmethod
    def listar():
        return [ColecionadorService.to_dict(colecionador) for colecionador in Colecionador.listar()]

    @staticmethod
    def buscar_por_id(colecionador_id):
        colecionador = db.session.get(Colecionador, colecionador_id)
        return ColecionadorService.to_dict(colecionador) if colecionador else None

    @staticmethod
    def criar(apelido, cidade):
        colecionador = Colecionador(apelido=apelido, cidade=cidade)
        db.session.add(colecionador)
        db.session.commit()
        return ColecionadorService.to_dict(colecionador)

    @staticmethod
    def to_dict(colecionador):
        return {
            "id": colecionador.id,
            "apelido": colecionador.apelido,
            "cidade": colecionador.cidade,
        }
